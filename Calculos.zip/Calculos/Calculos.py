from tkinter import *


expression =""

def appuyer(touche):
    if touche == "=":
        calculer()
        return
    global expression
    expression += str(touche)
    equation.set(expression)
def effacer():
    global expression
    text = resultat.cget("text")
    new_text = text.replace(text[-1], "", 1)
    resultat.config(text=new_text)
    expression = expression[:-1]
    equation.set(expression)

def dell(event):
    try:
        global expression
        text=label.cget("text")
        new_text = text.replace(text[-1], "", 1)
        resultat.config(text=new_text)
        expression = expression[:-1]
        equation.set(expression)
    except:
        expression = ""
        equation.set(expression)


def calculer():
    try:
       global expression

       total= str(eval(expression))

       equation.set(total)
       expression=total
    except:
        equation.set("erreur")
        expression = ""

def equale(event):
    calculer()
    return
window= Tk()

#fenetre couleur
window.configure(background="#177EC5")

#titre
window.title("CALCULO by VS")

#fenetre taille
window.geometry("256x350")
window.minsize(256,350)
window.maxsize(256,350)

equation = StringVar()

resultat= Label(window,justify="center",font=15 ,bg="#889A6C", fg="#fff", textvariable=equation)
resultat.grid(columnspan=4,sticky=E+W)
#boutton
boutons =[7,8,9,"*",4,5,6,"-",1,2,3,"+",0,",","/","="]
ligne=1
colonne=0
for i in boutons:
    b = Button(window,text=str(i),bg="#47A670",font=("europa",12), fg="#DBDFE2",height=3,width=6)
    b.bind("<Button-1>", lambda e, i=i: appuyer(i))
    b.grid(row=ligne,column=colonne)
    colonne+=1
    if colonne==4:
        colonne=0
        ligne+=1

b = Button(window,text="Effacer",bg="#F25A5A",font=("europa",12), fg="#DBDFE2",height=2)
b.bind("<Button-1>",lambda e:effacer())
b.grid(columnspan=4,sticky=E+W)
window.bind("<Escape>", dell)
window.bind("<space>",equale)

"""""
789*
456-
123+
0,/=
"""""

window.mainloop()